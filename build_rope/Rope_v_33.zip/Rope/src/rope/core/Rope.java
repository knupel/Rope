/**
 * Rope is the initializer
 *  but how that's work is like a mystery !
 * @author stan
 * 2018-2019
 * v 0.1.0
 * 
 */

package rope.core;

public class Rope extends BigBang implements R_Constants {
	public Rope() {
		
	}
}
