package rope.core;

public class Rope extends BigBangRope {
	
	public Rope() {
		
	}

}
