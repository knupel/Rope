/**
 * 
 * @author @stanlepunk
 * Here the contract for the Child class of R_Shape
 */
package rope.costume;
public interface R_Shape_contract {
	void build();
	
	void show();
	
	

}
