package costume;
import rope.core.*;

public class Costume implements RConstants {

}
