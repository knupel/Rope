/**
 * R_GUI
 * v0.0.2
 * 2021-2021
* @author Knupel / Stanislas Marçais
 *
 * Not sure I keep it
 *
 *
 *
 */
package rope.gui;
public interface R_GUI {
	void show_struc();
	void show_value();
	void update();
}
