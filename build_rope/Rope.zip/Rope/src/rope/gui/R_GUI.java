/**
 * R_GUI
 * v0.0.2
 * 2021-2021
 * @author stan
 *
 * Not sure I keep it
 *
 *
 *
 */
package rope.gui;
public interface R_GUI {
	void show_structure();
	void show_value();
	void update();

}
