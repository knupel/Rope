package rope.gui.bar;

import java.awt.event.ActionEvent;
/**
 * 
 * @author stan
 * Just a class Master to give the possibility to extends it and override the method what.
 */
public class R_Happen {
	public void what(String what, ActionEvent ae) {}
}
